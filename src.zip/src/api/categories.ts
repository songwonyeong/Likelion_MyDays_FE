// src/api/categories.ts
import { apiClient } from "../lib/apiClient";

export interface CategoryResp {
  id: number;
  name: string;
  color: string;
  order: number;
}

export async function getCategories() {
  const { data } = await apiClient.get<CategoryResp[]>("/api/categories");
  return data;
}

export async function createCategory(body: { name: string; color: string }) {
  const { data } = await apiClient.post<CategoryResp>("/api/categories", body);
  return data;
}
