// src/api/todos.ts
import { apiClient } from "../lib/apiClient";
import type { CategoryResp } from "./categories";

export interface TodoResp {
  id: number;
  title: string;
  memo: string | null;
  date: string; // yyyy-MM-dd
  time: string | null;
  completed: boolean;
  category: CategoryResp;
}

export async function getTodos(params?: { date?: string }) {
  const { data } = await apiClient.get<TodoResp[]>("/api/todos", { params });
  return data;
}

export async function createTodo(body: {
  categoryId: number;
  content: string; // ✅ 백엔드 스펙이 content면 그대로 유지
  date: string;
  time?: string;
}) {
  const { data } = await apiClient.post<TodoResp>("/api/todos", body);
  return data;
}

export async function toggleTodoDone(id: number, done: boolean) {
  const { data } = await apiClient.patch<TodoResp>(`/api/todos/${id}/done`, { done });
  return data;
}

export async function deleteTodo(id: number) {
  await apiClient.delete(`/api/todos/${id}`);
}
