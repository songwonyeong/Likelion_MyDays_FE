// src/lib/tokenStore.ts
const KEY = "access_token";

export function getAccessToken(): string | null {
  return sessionStorage.getItem(KEY);
}

export function setAccessToken(t: string | null) {
  if (!t) {
    sessionStorage.removeItem(KEY);
    return;
  }
  sessionStorage.setItem(KEY, t);
}

export function clearAccessToken() {
  sessionStorage.removeItem(KEY);
}
