// src/lib/apiClient.ts
import axios from "axios";
import { getAccessToken, setAccessToken, clearAccessToken } from "./tokenStore";

// ✅ 네 env는 VITE_API_BASE=http://localhost:8080 이었지
const API_BASE = import.meta.env.VITE_API_BASE ?? "http://localhost:8080";

export const apiClient = axios.create({
  baseURL: API_BASE,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

// ✅ (핵심) refresh 응답에서 accessToken 추출: body → header 순서
function extractAccessToken(res: any): string | null {
  // 1) body에 {accessToken:"..."} 로 오는 경우
  const bodyToken = res?.data?.accessToken;
  if (typeof bodyToken === "string" && bodyToken.length > 10) return bodyToken;

  // 2) Authorization: Bearer ... 로 오는 경우
  const h =
    res?.headers?.authorization ??
    res?.headers?.Authorization ??
    res?.headers?.AUTHORIZATION;

  if (typeof h === "string") {
    const m = h.match(/^Bearer\s+(.+)$/i);
    if (m?.[1]) return m[1];
  }

  return null;
}

// ✅ 요청: accessToken 붙이기
apiClient.interceptors.request.use((config) => {
  const t = getAccessToken();
  if (t) {
    config.headers = config.headers ?? {};
    (config.headers as any).Authorization = `Bearer ${t}`;
  }
  return config;
});

// ✅ 401이면 refresh 후 원요청 재시도(중복 refresh 방지)
let isRefreshing = false;
let waitQueue: Array<(token: string | null) => void> = [];

function pushQueue(cb: (token: string | null) => void) {
  waitQueue.push(cb);
}
function flushQueue(token: string | null) {
  waitQueue.forEach((cb) => cb(token));
  waitQueue = [];
}

apiClient.interceptors.response.use(
  (res) => res,
  async (error) => {
    const status = error?.response?.status;
    const original = error?.config;

    const isRefreshCall = original?.url?.includes("/auth/token/refresh");

    // ✅ refresh 호출 자체가 401이면 더 이상 재시도 X
    if (status !== 401 || original?._retry || isRefreshCall) {
      return Promise.reject(error);
    }

    original._retry = true;

    // 다른 요청들이 refresh 대기 중이면 queue에 태움
    if (isRefreshing) {
      return new Promise((resolve, reject) => {
        pushQueue((token) => {
          if (!token) return reject(error);
          original.headers = original.headers ?? {};
          original.headers.Authorization = `Bearer ${token}`;
          resolve(apiClient(original));
        });
      });
    }

    isRefreshing = true;

    try {
      // ✅ refresh는 쿠키 기반 (withCredentials=true)로 호출
      const res = await apiClient.post("/auth/token/refresh");

      const token = extractAccessToken(res);
      if (!token) {
        // 여기 걸리면: 백엔드가 token을 어디에도 안 준 것
        throw new Error("refresh 응답에서 accessToken을 찾지 못했습니다.");
      }

      setAccessToken(token);
      flushQueue(token);

      original.headers = original.headers ?? {};
      original.headers.Authorization = `Bearer ${token}`;
      return apiClient(original);
    } catch (e) {
      clearAccessToken();
      flushQueue(null);
      return Promise.reject(new Error("세션이 만료되었습니다. 다시 로그인해주세요."));
    } finally {
      isRefreshing = false;
    }
  }
);
