// src/App.tsx
import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Main from "./pages/Main";
import CategoryNew from "./pages/CategoryNew";

const isAuthed = () => !!localStorage.getItem("auth_token");
type GuardProps = { children: React.ReactNode };

function GuestOnly({ children }: GuardProps) {
  return isAuthed() ? <Navigate to="/" replace /> : <>{children}</>;
}
function RequireAuth({ children }: GuardProps) {
  return isAuthed() ? <>{children}</> : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* ✅ 공개 홈 */}
        <Route path="/" element={<Home />} />

        {/* 비로그인 전용 */}
        <Route
          path="/login"
          element={
            <GuestOnly>
              <Login />
            </GuestOnly>
          }
        />
        <Route
          path="/signup"
          element={
            <GuestOnly>
              <Signup />
            </GuestOnly>
          }
        />

        {/* 보호 라우트 */}
        <Route
          path="/main"
          element={
            <RequireAuth>
              <Main />
            </RequireAuth>
          }
        />
        <Route
          path="/category/new"
          element={
            <RequireAuth>
              <CategoryNew />
            </RequireAuth>
          }
        />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
