// src/pages/Home.tsx
import { Link, useNavigate } from "react-router-dom";
import "../styles/auth.css";

export default function Home() {
  const navigate = useNavigate();

  const handleKakaoLogin: React.MouseEventHandler<HTMLButtonElement> = (e) => {
    // ✅ 폼 submit/상위 onClick 차단
    e.preventDefault();
    e.stopPropagation();

    const clientId = import.meta.env.VITE_KAKAO_CLIENT_ID as string;
    const redirectUri = import.meta.env.VITE_KAKAO_REDIRECT_URI as string;

    if (!clientId || !redirectUri) {
      alert("카카오 환경변수가 없습니다. .env.local에 VITE_KAKAO_CLIENT_ID, VITE_KAKAO_REDIRECT_URI를 설정하세요.");
      return;
    }

    const url =
      `https://kauth.kakao.com/oauth/authorize?response_type=code` +
      `&client_id=${encodeURIComponent(clientId)}` +
      `&redirect_uri=${encodeURIComponent(redirectUri)}`;

    console.log("[KAKAO] redirect to:", url);
    // ✅ SPA 내부 네비 대신 '진짜' 외부 이동
    window.location.assign(url);
  };

  return (
    <div className="auth__wrap">
      <div className="auth__card" onClick={(e)=>e.stopPropagation()}>
        <h1 className="auth__title">My Days</h1>
        <p className="auth__subtitle">할 일을 작성하고 매일을 기록하세요.</p>

        <div className="auth__actions">
          <button
            type="button"
            className="btn btn--primary"
            onClick={() => navigate("/login")}
          >
            로그인
          </button>

          {/* ✅ 반드시 type="button" */}
          <button
            type="button"
            className="btn btn--kakao"
            onClick={handleKakaoLogin}
          >
            카카오 로그인
          </button>
        </div>

        <p className="auth__footer">
          회원이 아니신가요?{" "}
          <Link to="/signup" className="auth__link">회원가입</Link>
        </p>
      </div>
    </div>
  );
}
