import { useState } from "react"
import TopBar from "../components/TopBar"
import "../styles/auth.css"

export default function Signup() {
  const [email, setEmail] = useState("")
  const [code, setCode] = useState("")
  const [password, setPassword] = useState("")
  const [ageOk, setAgeOk] = useState(false)
  const [emailError, setEmailError] = useState("")
  const [codeError, setCodeError] = useState("")

  const handleSendCode = () => {
    if (!email.includes("@")) { setEmailError("올바른 이메일 형식이 아닙니다."); return }
    // TODO: 서버 응답 결과에 따라 setEmailError("이미 등록된 이메일 입니다.")
    setEmailError("")
  }
  const handleVerifyCode = () => {
    if (!code.trim()) { setCodeError("인증번호를 입력하세요."); return }
    // TODO: 서버 검증 후 실패 시 setCodeError("인증번호가 틀렸습니다.")
    setCodeError("")
  }
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!ageOk) return alert("만 14세 이상 동의가 필요합니다.")
    // TODO: /api/auth/signup
    alert("가입 시도 (데모)")
  }

  return (
    <>
      <TopBar title="회원가입" />
      <main className="page">
        <form className="form form--signup" onSubmit={submit}>
          {/* 이메일 + 버튼 (2열) */}
          <div className="field-inline">
            <input
              className="form__input"
              type="email"
              placeholder="이메일 등록"
              value={email}
              onChange={(e)=>{ setEmail(e.target.value); setEmailError(""); }}
            />
            <button type="button" className="btn btn--pill action-btn" onClick={handleSendCode}>
               인증코드 전송
            </button>
          </div>
          {emailError && <p className="form__help is-error">{emailError}</p>}

          {/* 인증코드 + 버튼 (2열) */}
          <div className="field-inline">
            <input
              className="form__input"
              type="text"
              placeholder="인증번호 입력"
              value={code}
              onChange={(e)=>{ setCode(e.target.value); setCodeError(""); }}
            />
            <button type="button" className="btn btn--pill action-btn" onClick={handleVerifyCode}>
              확인
            </button>
          </div>
          {codeError && <p className="form__help is-error">{codeError}</p>}

          {/* 비밀번호 (단일열) → 이메일과 동일 폭 유지 */}
          <div className="field-single">
            <input
              className="form__input"
              type="password"
              placeholder="비밀번호 등록"
              value={password}
              onChange={(e)=>setPassword(e.target.value)}
            />
          </div>

          <label className="form__row" style={{ marginTop: 16 }}>
            <input type="checkbox" checked={ageOk} onChange={(e)=>setAgeOk(e.target.checked)} />
            <span>[필수] 만 14세 이상입니다.</span>
          </label>

          <button type="submit" className="btn btn--primary btn--xl">가입하기</button>
        </form>
      </main>
    </>
  )
}
