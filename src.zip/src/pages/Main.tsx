// src/pages/Main.tsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCategories, toKey } from "../hooks/useCategories";
import Calendar from "../components/Calendar";
import CategoryList from "../components/CategoryList";
import MainTopBar from "../components/MainTopBar";
import { apiClient } from "../lib/apiClient";
import { setAccessToken, clearAccessToken } from "../lib/tokenStore";

export default function Main() {
  const nav = useNavigate();
  const store = useCategories();

  // ✅ (1) 날짜 관련 state들 먼저 선언 (Hook 순서 고정)
  const [baseDate, setBaseDate] = useState(() => {
    const t = new Date();
    t.setDate(1);
    return t;
  });

  const [selectedDate, setSelectedDate] = useState(new Date());
  const dateKey = useMemo(() => toKey(selectedDate), [selectedDate]);

  // ✅ (2) 로그인 세션 확인용
  const [ready, setReady] = useState(false);

  // ✅ (3) 페이지 진입 시 refresh 1회 시도
  useEffect(() => {
    let alive = true;

    (async () => {
      try {
        const res = await apiClient.post("/auth/token/refresh");

        // apiClient가 interceptor에서 setAccessToken 해주지만,
        // 혹시 모르니 여기서도 ready만 켬
        if (alive) setReady(true);
      } catch (e) {
        clearAccessToken();
        if (alive) nav("/login", { replace: true });
      }
    })();

    return () => {
      alive = false;
    };
  }, [nav]);

  // ✅ (4) selectedDate가 바뀔 때 store도 같이 갱신
  useEffect(() => {
    store.setSelectedDateKey(dateKey);
  }, [dateKey, store]);

  // ✅ (5) store refresh는 "ready 된 이후"에만
  useEffect(() => {
    if (!ready) return;
    store.refresh().catch(() => {
      // refresh 성공했는데도 /api가 401이면 여기로 올 수 있음
      // (대부분 accessToken 파싱 문제였는데 apiClient에서 해결됨)
    });
  }, [ready, store]);

  // ✅ 렌더는 마지막에 조건 처리
  if (!ready) {
    return (
      <>
        <MainTopBar title="MyDays" />
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "24px 16px" }}>
          로그인 확인 중...
        </div>
      </>
    );
  }

  return (
    <>
      <MainTopBar title="MyDays" />

      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "24px 16px" }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "2fr 1fr",
            gap: 28,
            alignItems: "start",
          }}
        >
          <section>
            <Calendar
              baseDate={baseDate}
              selectedDate={selectedDate}
              onPrevMonth={() =>
                setBaseDate(new Date(baseDate.getFullYear(), baseDate.getMonth() - 1, 1))
              }
              onNextMonth={() =>
                setBaseDate(new Date(baseDate.getFullYear(), baseDate.getMonth() + 1, 1))
              }
              onSelectDate={(d) => setSelectedDate(d)}
              getMeta={(d) => store.getDayStats(toKey(d))}
            />
          </section>

          <aside className="transition-all duration-200 ease-out">
            <div key={dateKey} className="animate-[fadeIn_.18s_ease-out]">
              <CategoryList
                dateKey={dateKey}
                categories={store.categories}
                addTodo={(catId, title) => store.addTodo(catId, title, dateKey)}
                toggleTodo={(catId, todoId) => store.toggleTodo(catId, todoId)}
                reorderCategory={store.reorderCategory}
                reorderTodo={store.reorderTodo}
              />
            </div>
          </aside>
        </div>
      </div>
    </>
  );
}
