// src/hooks/useAuth.ts
import { useEffect, useState } from "react";
import { getAccessToken } from "../lib/tokenStore";

export function useAuth(): boolean | null {
  const [authed, setAuthed] = useState<boolean | null>(null);

  useEffect(() => {
    const token = getAccessToken() ?? (window as any).__ACCESS_TOKEN__ ?? null;
    setAuthed(!!token);
  }, []);

  return authed;
}
