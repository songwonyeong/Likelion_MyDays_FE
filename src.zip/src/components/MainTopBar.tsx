import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { logout } from "../api/auth";


type Props = { title?: string };

type UserInfo = {
  name?: string;
  email?: string;
  provider?: "LOCAL" | "KAKAO" | string;
  // 필요하면 더 추가
};

export default function MainTopBar({ title = "MyDays" }: Props) {
  const nav = useNavigate();

  const [openMenu, setOpenMenu] = useState(false);
  const [openLogoutModal, setOpenLogoutModal] = useState(false);
  const [openMeModal, setOpenMeModal] = useState(false);

  // 내정보 임시값 (나중에 백엔드 연결하면 여기만 바꾸면 됨)
  const [me, setMe] = useState<UserInfo>({
    name: "사용자",
    email: "user@example.com",
    provider: "LOCAL",
  });

  const menuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (!menuRef.current) return;
      if (!menuRef.current.contains(e.target as Node)) setOpenMenu(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  // 모달 열리면 스크롤 잠금(선택)
  useEffect(() => {
    const isAnyModalOpen = openLogoutModal || openMeModal;
    if (isAnyModalOpen) document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [openLogoutModal, openMeModal]);

  const go = (path: string) => {
    setOpenMenu(false);
    nav(path);
  };

  const requestLogout = () => {
    setOpenMenu(false);
    setOpenLogoutModal(true);
  };

  const openMe = () => {
    setOpenMenu(false);
    setOpenMeModal(true);
  };

  const confirmLogout = async () => {
    try {
      await logout();
    } catch {
      // 서버 실패해도 프론트 토큰은 지움
    } finally {
      (window as any).__ACCESS_TOKEN__ = null;
      setOpenLogoutModal(false);
      nav("/", { replace: true });
    }
  };

  return (
    <>
      {/* 상단바 */}
      <header className="sticky top-0 z-50 bg-gray-50">
        <div className="relative max-w-[1180px] mx-auto h-16 px-4 flex items-center justify-between">
          <div className="w-11" />

          {/* 가운데 로고 */}
          <div className="absolute left-1/2 -translate-x-1/2 font-extrabold text-4xl tracking-tight text-gray-900">
            {title}
          </div>

          {/* 오른쪽 + 메뉴 */}
          <div className="relative" ref={menuRef}>
            <button
              type="button"
              onClick={() => setOpenMenu((v) => !v)}
              className="
                w-11 h-11 rounded-2xl
                bg-white text-black
                border border-gray-200
                shadow-sm
                flex items-center justify-center
                hover:bg-gray-100
                transition-colors
              "
              aria-label="메뉴 열기"
            >
              <span className="text-2xl leading-none">+</span>
            </button>

            {openMenu && (
              <div
                className="
                  absolute right-0 mt-3 w-60
                  rounded-2xl bg-white
                  border border-gray-200
                  shadow-lg overflow-hidden
                "
              >
                <MenuItem label="카테고리 등록" onClick={() => go("/category/new")} />
                <MenuItem label="카테고리 관리" onClick={() => go("/category/manage")} />
                <MenuItem label="AI 할일 생성" onClick={() => go("/ai/todo")} />
                <MenuItem label="내 정보" onClick={openMe} />
                <div className="h-px bg-gray-100" />
                <MenuItem label="로그아웃" danger onClick={requestLogout} />
              </div>
            )}
          </div>
        </div>
      </header>

      {/* 로그아웃 확인 모달 */}
      <CenterModal
        open={openLogoutModal}
        title="로그아웃"
        onClose={() => setOpenLogoutModal(false)}
      >
        <p className="text-sm text-gray-700">로그아웃 하시겠습니까?</p>

        <div className="mt-5 flex justify-end gap-2">
          <button
            type="button"
            onClick={() => setOpenLogoutModal(false)}
            className="px-3 py-2 rounded-xl border border-gray-200 bg-white text-gray-900 hover:bg-gray-50"
          >
            취소
          </button>
          <button
            type="button"
            onClick={confirmLogout}
            className="px-3 py-2 rounded-xl bg-gray-900 text-white hover:bg-black"
          >
            로그아웃
          </button>
        </div>
      </CenterModal>

      {/* 내 정보 모달 */}
      <CenterModal open={openMeModal} title="내 정보" onClose={() => setOpenMeModal(false)}>
        <div className="space-y-3">
          <InfoRow label="이름" value={me.name ?? "-"} />
          <InfoRow label="이메일" value={me.email ?? "-"} />
          <InfoRow label="로그인 방식" value={me.provider ?? "-"} />
        </div>

        <div className="mt-6 flex justify-end">
          <button
            type="button"
            onClick={() => setOpenMeModal(false)}
            className="px-3 py-2 rounded-xl border border-gray-200 bg-white text-gray-900 hover:bg-gray-50"
          >
            닫기
          </button>
        </div>
      </CenterModal>
    </>
  );
}

function MenuItem({
  label,
  onClick,
  danger,
}: {
  label: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "w-full text-left px-4 py-3 text-sm font-medium transition-colors",
        "bg-white text-gray-900 hover:bg-gray-50 active:bg-gray-100",
        danger ? "text-red-600 hover:bg-red-50 active:bg-red-100" : "",
      ].join(" ")}
    >
      {label}
    </button>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-xl border border-gray-200 bg-white px-3 py-2">
      <span className="text-sm font-semibold text-gray-700">{label}</span>
      <span className="text-sm text-gray-900">{value}</span>
    </div>
  );
}

function CenterModal({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/30 px-4"
      onMouseDown={onClose}
    >
      <div
        className="w-full max-w-[420px] rounded-2xl bg-white border border-gray-200 shadow-xl p-5"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-base font-extrabold text-gray-900">{title}</h3>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl border border-gray-200 bg-white hover:bg-gray-50"
            aria-label="닫기"
          >
            ✕
          </button>
        </div>

        {children}
      </div>
    </div>
  );
}
